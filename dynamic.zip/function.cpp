#include "stdafx.h"

int maxnum(int a, int b) {
	return a > b ? a : b;
}