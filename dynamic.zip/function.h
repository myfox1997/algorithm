#pragma once

int maxnum(int a, int b);
