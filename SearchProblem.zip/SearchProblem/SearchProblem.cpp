// SearchProblem.cpp : �������̨Ӧ�ó������ڵ㡣
//this problem called  'prime circles'

#include "stdafx.h"

int ans[22];
bool hash[22];
int n;

int primeNum[] = { 2, 3, 5, 7, 11, 17, 19, 23, 29, 31, 37, 41 };

bool isPrime(int x) {
	for (int i = 0; i < sizeof(primeNum) / sizeof(primeNum[0]); i++) {
		if (x == primeNum[i])
			return true;
	}
	return false;
}

void check() {
	if (isPrime(ans[n] + ans[1]) == false)
		return;

	for (int i = 1; i <= n; i++) {
		if (i != 1)
			printf(" ");
		printf("%d", ans[i]);
	}
	printf("\n");
}

void DFS(int Num) {
	if (Num > 1)
		if (isPrime(ans[Num] + ans[Num - 1]) == false)
			return;

	if (Num == n)
	{
		check();
		return;
	}

	for (int i = 2; i <= n; i++) {
		if (hash[i] == false) {
			hash[i] = true;
			ans[Num + 1] = i;
			DFS(Num + 1);
			hash[i] = false;
		}
	}
}

int main()
{
	int CASE = 0;
	while (scanf("%d", &n) != EOF)
	{
		CASE++;
		for (int i = 0; i < 22; i++) {
			hash[i] = false;
		}
		ans[1] = 1;
		printf("Case %d:\n", CASE);
		hash[1] = true;
		DFS(1);
		printf("\n");
	}
    return 0;
}

